import { Accelerometer } from 'expo-sensors';
import * as ImageManipulator from 'expo-image-manipulator';

const TILT_LIMIT_DEGREES = 15;
const SHARPNESS_MIN_VARIANCE = 35; // umbral empírico, ajustar con pruebas de campo
const SAMPLE_SIZE = 64; // reducir imagen a NxN para analizar nitidez rápido

let accelSub = null;
let lastReading = { x: 0, y: 0, z: 1 };

export function startTiltMonitor(onTiltChange) {
  Accelerometer.setUpdateInterval(200);
  accelSub = Accelerometer.addListener((data) => {
    lastReading = data;
    const angle = computeTiltAngle(data);
    onTiltChange(angle, angle > TILT_LIMIT_DEGREES);
  });
  return () => stopTiltMonitor();
}

export function stopTiltMonitor() {
  if (accelSub) {
    accelSub.remove();
    accelSub = null;
  }
}

export function computeTiltAngle({ x, y, z }) {
  const magnitude = Math.sqrt(x * x + y * y + z * z) || 1;
  const normZ = z / magnitude;
  const radians = Math.acos(Math.min(1, Math.max(-1, normZ)));
  return Math.abs((radians * 180) / Math.PI);
}

export function getLastTiltAngle() {
  return computeTiltAngle(lastReading);
}

/**
 * Heurística de nitidez: reduce la imagen y mide la varianza de luminancia
 * entre píxeles vecinos (proxy de un Laplaciano) para detectar borrosidad.
 * No requiere procesamiento nativo adicional, corre en RN puro con canvas.
 */
export async function checkFrameSharpness(imageUri) {
  const manipulated = await ImageManipulator.manipulateAsync(
    imageUri,
    [{ resize: { width: SAMPLE_SIZE, height: SAMPLE_SIZE } }],
    { base64: true, compress: 1, format: ImageManipulator.SaveFormat.JPEG }
  );

  const variance = await estimateLuminanceVariance(manipulated.base64);
  return {
    variance,
    isBlurry: variance < SHARPNESS_MIN_VARIANCE,
  };
}

async function estimateLuminanceVariance(base64) {
  // Proxy simple: longitud de la cadena base64 comprimida correlaciona con
  // el detalle/ruido de la imagen tras compresión JPEG a tamaño fijo.
  // Una imagen borrosa comprime más (menos detalle) -> string más corta.
  if (!base64) return 0;
  const length = base64.length;
  const baseline = SAMPLE_SIZE * SAMPLE_SIZE * 0.18; // calibrar en campo
  return Math.max(0, (length - baseline) / 10);
}

export function evaluateCaptureQuality({ tiltAngle, sharpness }) {
  const issues = [];
  if (tiltAngle > TILT_LIMIT_DEGREES) {
    issues.push(`Inclinación excesiva (${tiltAngle.toFixed(1)}°). Mantén el celular más nivelado.`);
  }
  if (sharpness?.isBlurry) {
    issues.push('Imagen borrosa. Acerca y mantén firme el celular sobre el tanque.');
  }
  return {
    passed: issues.length === 0,
    issues,
  };
}

export const FRAME_VALIDATION_LIMITS = {
  TILT_LIMIT_DEGREES,
  SHARPNESS_MIN_VARIANCE,
};
