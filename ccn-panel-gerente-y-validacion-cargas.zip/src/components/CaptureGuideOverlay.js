import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import colors from '../theme/colors';

export default function CaptureGuideOverlay({ tiltAngle = 0, tiltBad = false, blurBad = false, countdown = null }) {
  const frameOk = !tiltBad && !blurBad;

  return (
    <View style={styles.overlay} pointerEvents="none">
      <View
        style={[
          styles.guideCircle,
          { borderColor: frameOk ? colors.success : colors.danger },
        ]}
      />

      {countdown !== null && (
        <View style={styles.countdownBadge}>
          <Text style={styles.countdownText}>{countdown}s</Text>
        </View>
      )}

      <View style={styles.statusBar}>
        {tiltBad && (
          <Text style={styles.warningText}>⚠ Nivela el celular ({tiltAngle.toFixed(0)}°)</Text>
        )}
        {blurBad && <Text style={styles.warningText}>⚠ Enfoca el tanque, imagen borrosa</Text>}
        {frameOk && <Text style={styles.okText}>✓ Encuadre correcto</Text>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
  },
  guideCircle: {
    width: '70%',
    aspectRatio: 1,
    borderWidth: 4,
    borderRadius: 999,
    borderStyle: 'dashed',
  },
  countdownBadge: {
    position: 'absolute',
    top: 40,
    backgroundColor: 'rgba(0,0,0,0.6)',
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 20,
  },
  countdownText: {
    color: colors.text,
    fontSize: 20,
    fontWeight: '700',
  },
  statusBar: {
    position: 'absolute',
    bottom: 50,
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: 'rgba(0,0,0,0.6)',
    borderRadius: 12,
  },
  warningText: {
    color: colors.danger,
    fontWeight: '700',
    textAlign: 'center',
  },
  okText: {
    color: colors.success,
    fontWeight: '700',
    textAlign: 'center',
  },
});
