import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import colors from '../theme/colors';

export default function ModuleCard({ title, color = colors.primary, onPress, disabled = false }) {
  return (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: color }, disabled && styles.disabled]}
      onPress={disabled ? undefined : onPress}
      activeOpacity={0.75}
      disabled={disabled}
    >
      <Text style={styles.title}>{title}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    width: '48%',
    minHeight: 100,
    borderRadius: 14,
    padding: 14,
    marginBottom: 14,
    justifyContent: 'flex-end',
  },
  disabled: {
    opacity: 0.4,
  },
  title: {
    color: '#FFFFFF',
    fontWeight: '800',
    fontSize: 15,
  },
});
