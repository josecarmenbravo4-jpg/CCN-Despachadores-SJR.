import * as SQLite from 'expo-sqlite';

let dbInstance = null;

export async function getDb() {
  if (dbInstance) return dbInstance;
  dbInstance = await SQLite.openDatabaseAsync('ccn_despachadores.db');
  await initSchema(dbInstance);
  return dbInstance;
}

async function initSchema(db) {
  await db.execAsync(`
    PRAGMA journal_mode = WAL;

    CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nombre TEXT NOT NULL,
      usuario TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      rol TEXT NOT NULL CHECK (rol IN ('despachador', 'gerente')),
      calificacion REAL NOT NULL DEFAULT 10.0,
      productividad INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS cargas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER,
      numero_economico TEXT,
      tipo TEXT CHECK (tipo IN ('diesel', 'urea')),
      litros REAL NOT NULL DEFAULT 0,
      fecha TEXT NOT NULL DEFAULT (datetime('now')),
      video_uri TEXT,
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    );

    CREATE TABLE IF NOT EXISTS validaciones (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      carga_id INTEGER,
      resultado TEXT,
      fecha TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (carga_id) REFERENCES cargas(id)
    );

    CREATE TABLE IF NOT EXISTS inventario (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nivel_litros REAL NOT NULL,
      fecha TEXT NOT NULL DEFAULT (datetime('now')),
      origen TEXT DEFAULT 'manual'
    );

    CREATE TABLE IF NOT EXISTS observaciones (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER,
      incidencia_id INTEGER,
      texto TEXT NOT NULL,
      fecha TEXT NOT NULL DEFAULT (datetime('now')),
      leida INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    );

    CREATE TABLE IF NOT EXISTS incidencias (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER,
      numero_economico TEXT,
      tipo TEXT,
      severidad TEXT CHECK (severidad IN ('baja', 'media', 'alta')) DEFAULT 'media',
      descripcion TEXT,
      video_uri TEXT,
      estado TEXT CHECK (estado IN ('pendiente', 'notificada', 'resuelta')) DEFAULT 'pendiente',
      fecha TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    );

    CREATE TABLE IF NOT EXISTS turnos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER,
      inicio TEXT,
      fin TEXT,
      pdf_uri TEXT,
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    );
  `);
}
