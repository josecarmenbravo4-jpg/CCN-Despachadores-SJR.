import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
} from 'react-native';
import { Video } from 'expo-av';
import colors from '../../theme/colors';
import { getDb } from '../../db/database';

export default function IncidentsScreen() {
  const [incidents, setIncidents] = useState([]);
  const [selected, setSelected] = useState(null);
  const [observation, setObservation] = useState('');
  const [videoVisible, setVideoVisible] = useState(false);

  const loadIncidents = useCallback(async () => {
    const db = await getDb();
    const rows = await db.getAllAsync(
      `SELECT i.*, u.nombre as despachador_nombre
       FROM incidencias i
       LEFT JOIN usuarios u ON u.id = i.usuario_id
       WHERE i.estado != 'resuelta'
       ORDER BY i.fecha DESC`
    );
    setIncidents(rows);
  }, []);

  useEffect(() => {
    loadIncidents();
  }, [loadIncidents]);

  const openIncident = (item) => {
    setSelected(item);
    setObservation('');
  };

  const sendObservation = async () => {
    if (!selected || !observation.trim()) return;
    const db = await getDb();
    await db.runAsync(
      `INSERT INTO observaciones (usuario_id, incidencia_id, texto, fecha, leida)
       VALUES (?, ?, ?, datetime('now'), 0)`,
      [selected.usuario_id, selected.id, observation.trim()]
    );
    await db.runAsync(`UPDATE incidencias SET estado = 'notificada' WHERE id = ?`, [selected.id]);
    Alert.alert('Enviado', 'La observación se envió al despachador.');
    setObservation('');
    setSelected(null);
    loadIncidents();
  };

  const renderItem = ({ item }) => (
    <TouchableOpacity style={styles.card} onPress={() => openIncident(item)}>
      <View style={[styles.severityDot, { backgroundColor: item.severidad === 'alta' ? colors.danger : colors.warning }]} />
      <View style={{ flex: 1 }}>
        <Text style={styles.cardTitle}>{item.tipo} · {item.despachador_nombre || 'N/D'}</Text>
        <Text style={styles.cardSubtitle}>Económico {item.numero_economico} · {item.fecha}</Text>
        <Text style={styles.cardDesc} numberOfLines={2}>{item.descripcion}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Incidencias / Alertas IA</Text>
      <FlatList
        data={incidents}
        keyExtractor={(item) => String(item.id)}
        renderItem={renderItem}
        ListEmptyComponent={<Text style={styles.empty}>Sin incidencias pendientes.</Text>}
        contentContainerStyle={{ paddingBottom: 40 }}
      />

      <Modal visible={!!selected} animationType="slide" onRequestClose={() => setSelected(null)}>
        <View style={styles.modalContainer}>
          {selected && (
            <>
              <Text style={styles.modalTitle}>{selected.tipo}</Text>
              <Text style={styles.modalSubtitle}>
                {selected.despachador_nombre} · Económico {selected.numero_economico}
              </Text>
              <Text style={styles.modalDesc}>{selected.descripcion}</Text>

              {selected.video_uri && (
                <TouchableOpacity style={styles.videoBtn} onPress={() => setVideoVisible(true)}>
                  <Text style={styles.videoBtnText}>▶ Ver video de la carga</Text>
                </TouchableOpacity>
              )}

              <Text style={styles.label}>Enviar observación</Text>
              <TextInput
                style={styles.input}
                multiline
                placeholder="Escribe la observación para el despachador..."
                placeholderTextColor={colors.textMuted}
                value={observation}
                onChangeText={setObservation}
              />

              <View style={styles.modalActions}>
                <TouchableOpacity style={styles.cancelBtn} onPress={() => setSelected(null)}>
                  <Text style={styles.cancelBtnText}>Cerrar</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.sendBtn} onPress={sendObservation}>
                  <Text style={styles.sendBtnText}>Enviar</Text>
                </TouchableOpacity>
              </View>
            </>
          )}
        </View>
      </Modal>

      <Modal visible={videoVisible} animationType="fade" onRequestClose={() => setVideoVisible(false)}>
        <View style={styles.videoModal}>
          {selected?.video_uri && (
            <Video
              source={{ uri: selected.video_uri }}
              useNativeControls
              resizeMode="contain"
              style={styles.video}
              shouldPlay
            />
          )}
          <TouchableOpacity style={styles.closeVideoBtn} onPress={() => setVideoVisible(false)}>
            <Text style={styles.videoBtnText}>Cerrar</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 16 },
  header: { color: colors.text, fontSize: 20, fontWeight: '800', marginBottom: 12 },
  empty: { color: colors.textMuted, textAlign: 'center', marginTop: 40 },
  card: {
    flexDirection: 'row',
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    alignItems: 'flex-start',
    borderWidth: 1,
    borderColor: colors.border,
  },
  severityDot: { width: 10, height: 10, borderRadius: 5, marginTop: 6, marginRight: 10 },
  cardTitle: { color: colors.text, fontWeight: '700' },
  cardSubtitle: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
  cardDesc: { color: colors.textMuted, fontSize: 13, marginTop: 4 },
  modalContainer: { flex: 1, backgroundColor: colors.background, padding: 20, paddingTop: 60 },
  modalTitle: { color: colors.text, fontSize: 22, fontWeight: '800' },
  modalSubtitle: { color: colors.textMuted, marginTop: 4, marginBottom: 12 },
  modalDesc: { color: colors.text, marginBottom: 16 },
  videoBtn: {
    backgroundColor: colors.primary,
    padding: 12,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 20,
  },
  videoBtnText: { color: colors.text, fontWeight: '700' },
  label: { color: colors.text, fontWeight: '700', marginBottom: 6 },
  input: {
    backgroundColor: colors.surface,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.border,
    color: colors.text,
    padding: 12,
    minHeight: 90,
    textAlignVertical: 'top',
  },
  modalActions: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 20 },
  cancelBtn: { padding: 12, marginRight: 8 },
  cancelBtnText: { color: colors.textMuted, fontWeight: '700' },
  sendBtn: { backgroundColor: colors.primary, paddingHorizontal: 20, paddingVertical: 12, borderRadius: 10 },
  sendBtnText: { color: colors.text, fontWeight: '700' },
  videoModal: { flex: 1, backgroundColor: '#000', justifyContent: 'center' },
  video: { width: '100%', height: '70%' },
  closeVideoBtn: { alignSelf: 'center', marginTop: 20, padding: 12 },
});
