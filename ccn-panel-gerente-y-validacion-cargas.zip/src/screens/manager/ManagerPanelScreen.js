import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import ModuleCard from '../../components/ModuleCard';
import colors from '../../theme/colors';

export default function ManagerPanelScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.logoText}>CCN DESPACHADORES SJR</Text>
        <Text style={styles.title}>Panel del Gerente</Text>
      </View>

      <View style={styles.grid}>
        <ModuleCard
          title="Incidencias / Alertas IA"
          color={colors.primary}
          onPress={() => navigation.navigate('IncidentsScreen')}
        />
        <ModuleCard
          title="Control de Usuarios"
          color={colors.accentBlue}
          onPress={() => navigation.navigate('UsersControlScreen')}
        />
        <ModuleCard
          title="Control de Inventarios"
          color={colors.accentYellow}
          onPress={() => navigation.navigate('InventoryControlScreen')}
        />
        <ModuleCard
          title="Ranking de Empleados"
          color={colors.accentPurple}
          onPress={() => navigation.navigate('RankingScreen')}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 16 },
  header: { alignItems: 'center', marginBottom: 24 },
  logoText: { color: colors.primary, fontWeight: '900', fontSize: 16, letterSpacing: 1, marginBottom: 4 },
  title: { color: colors.text, fontSize: 22, fontWeight: '800' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
});
