import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Modal, TextInput, Alert } from 'react-native';
import colors from '../../theme/colors';
import { getDb } from '../../db/database';

export default function UsersControlScreen() {
  const [users, setUsers] = useState([]);
  const [selected, setSelected] = useState(null);
  const [newPassword, setNewPassword] = useState('');

  const loadUsers = useCallback(async () => {
    const db = await getDb();
    const rows = await db.getAllAsync(`SELECT * FROM usuarios WHERE rol = 'despachador' ORDER BY nombre`);
    setUsers(rows);
  }, []);

  useEffect(() => { loadUsers(); }, [loadUsers]);

  const resetPassword = async () => {
    if (!selected || newPassword.trim().length < 4) {
      Alert.alert('Contraseña inválida', 'Debe tener al menos 4 caracteres.');
      return;
    }
    const db = await getDb();
    await db.runAsync(`UPDATE usuarios SET password = ? WHERE id = ?`, [newPassword.trim(), selected.id]);
    Alert.alert('Listo', `Contraseña de ${selected.nombre} actualizada.`);
    setSelected(null);
    setNewPassword('');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Control de Usuarios</Text>
      <FlatList
        data={users}
        keyExtractor={(item) => String(item.id)}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>{item.nombre}</Text>
              <Text style={styles.cardSubtitle}>Usuario: {item.usuario}</Text>
            </View>
            <TouchableOpacity style={styles.resetBtn} onPress={() => setSelected(item)}>
              <Text style={styles.resetBtnText}>Reset</Text>
            </TouchableOpacity>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>Sin despachadores registrados.</Text>}
      />

      <Modal visible={!!selected} transparent animationType="fade" onRequestClose={() => setSelected(null)}>
        <View style={styles.overlay}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>Reset de contraseña</Text>
            <Text style={styles.modalSubtitle}>{selected?.nombre}</Text>
            <TextInput
              style={styles.input}
              placeholder="Nueva contraseña"
              placeholderTextColor={colors.textMuted}
              secureTextEntry
              keyboardType="numeric"
              value={newPassword}
              onChangeText={setNewPassword}
            />
            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => { setSelected(null); setNewPassword(''); }}>
                <Text style={styles.cancelBtnText}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.sendBtn} onPress={resetPassword}>
                <Text style={styles.sendBtnText}>Guardar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 16 },
  header: { color: colors.text, fontSize: 20, fontWeight: '800', marginBottom: 12 },
  empty: { color: colors.textMuted, textAlign: 'center', marginTop: 40 },
  card: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surface,
    borderRadius: 12, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: colors.border,
  },
  cardTitle: { color: colors.text, fontWeight: '700' },
  cardSubtitle: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
  resetBtn: { backgroundColor: colors.accentBlue, paddingHorizontal: 16, paddingVertical: 8, borderRadius: 8 },
  resetBtnText: { color: colors.text, fontWeight: '700' },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', padding: 24 },
  modalBox: { backgroundColor: colors.surface, borderRadius: 14, padding: 20 },
  modalTitle: { color: colors.text, fontSize: 18, fontWeight: '800' },
  modalSubtitle: { color: colors.textMuted, marginTop: 2, marginBottom: 14 },
  input: {
    backgroundColor: colors.surfaceAlt, borderRadius: 10, borderWidth: 1, borderColor: colors.border,
    color: colors.text, padding: 12,
  },
  modalActions: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 18 },
  cancelBtn: { padding: 12, marginRight: 8 },
  cancelBtnText: { color: colors.textMuted, fontWeight: '700' },
  sendBtn: { backgroundColor: colors.accentBlue, paddingHorizontal: 20, paddingVertical: 12, borderRadius: 10 },
  sendBtnText: { color: colors.text, fontWeight: '700' },
});
