import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import colors from '../../theme/colors';
import { getDb } from '../../db/database';

export default function RankingScreen() {
  const [ranking, setRanking] = useState([]);

  const loadRanking = useCallback(async () => {
    const db = await getDb();
    const rows = await db.getAllAsync(
      `SELECT id, nombre, calificacion, productividad
       FROM usuarios
       WHERE rol = 'despachador'
       ORDER BY calificacion DESC, productividad DESC`
    );
    setRanking(rows);
  }, []);

  useEffect(() => { loadRanking(); }, [loadRanking]);

  const medalColor = (index) => {
    if (index === 0) return '#FFD700';
    if (index === 1) return '#C0C0C0';
    if (index === 2) return '#CD7F32';
    return colors.border;
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Ranking de Empleados</Text>
      <FlatList
        data={ranking}
        keyExtractor={(item) => String(item.id)}
        renderItem={({ item, index }) => (
          <View style={styles.card}>
            <View style={[styles.rankBadge, { backgroundColor: medalColor(index) }]}>
              <Text style={styles.rankNumber}>{index + 1}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.name}>{item.nombre}</Text>
              <Text style={styles.productividad}>{item.productividad} cargas completadas</Text>
            </View>
            <View style={styles.stars}>
              <Text style={styles.rating}>{item.calificacion.toFixed(1)} ★</Text>
            </View>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>Sin despachadores registrados.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 16 },
  header: { color: colors.text, fontSize: 20, fontWeight: '800', marginBottom: 12 },
  empty: { color: colors.textMuted, textAlign: 'center', marginTop: 40 },
  card: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surface,
    borderRadius: 12, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: colors.border,
  },
  rankBadge: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  rankNumber: { color: '#000', fontWeight: '800' },
  name: { color: colors.text, fontWeight: '700' },
  productividad: { color: colors.textMuted, fontSize: 12, marginTop: 2 },
  stars: { paddingLeft: 8 },
  rating: { color: colors.accentYellow, fontWeight: '800', fontSize: 16 },
});
