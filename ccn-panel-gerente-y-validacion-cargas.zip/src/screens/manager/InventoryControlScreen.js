import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, ScrollView, Alert } from 'react-native';
import colors from '../../theme/colors';
import { getDb } from '../../db/database';

const LOW_LEVEL_THRESHOLD = 10000;
const PERIODS = [
  { key: 'day', label: 'Día' },
  { key: 'week', label: 'Semana' },
  { key: 'month', label: 'Mes' },
  { key: 'year', label: 'Año' },
];

export default function InventoryControlScreen() {
  const [period, setPeriod] = useState('day');
  const [consumo, setConsumo] = useState({ diesel: 0, urea: 0 });
  const [nivelTanque, setNivelTanque] = useState(null);
  const [lecturaManual, setLecturaManual] = useState('');

  const loadConsumo = useCallback(async (p) => {
    const db = await getDb();
    const intervalMap = {
      day: "-1 day",
      week: "-7 day",
      month: "-1 month",
      year: "-1 year",
    };
    const row = await db.getFirstAsync(
      `SELECT
         SUM(CASE WHEN tipo = 'diesel' THEN litros ELSE 0 END) as diesel,
         SUM(CASE WHEN tipo = 'urea' THEN litros ELSE 0 END) as urea
       FROM cargas
       WHERE fecha >= datetime('now', ?)`,
      [intervalMap[p]]
    );
    setConsumo({ diesel: row?.diesel || 0, urea: row?.urea || 0 });

    const inv = await db.getFirstAsync(`SELECT nivel_litros FROM inventario ORDER BY fecha DESC LIMIT 1`);
    setNivelTanque(inv?.nivel_litros ?? null);
  }, []);

  useEffect(() => { loadConsumo(period); }, [period, loadConsumo]);

  const guardarLectura = async () => {
    const valor = parseFloat(lecturaManual);
    if (Number.isNaN(valor) || valor < 0) {
      Alert.alert('Valor inválido', 'Ingresa un número de litros válido.');
      return;
    }
    const db = await getDb();
    await db.runAsync(
      `INSERT INTO inventario (nivel_litros, fecha, origen) VALUES (?, datetime('now'), 'manual')`,
      [valor]
    );
    setNivelTanque(valor);
    setLecturaManual('');
    Alert.alert('Guardado', 'Lectura manual registrada.');
  };

  const nivelBajo = nivelTanque !== null && nivelTanque < LOW_LEVEL_THRESHOLD;

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 40 }}>
      <Text style={styles.header}>Control de Inventarios</Text>

      <View style={[styles.levelCard, nivelBajo && styles.levelCardAlert]}>
        <Text style={styles.levelLabel}>Nivel actual del tanque</Text>
        <Text style={[styles.levelValue, nivelBajo && styles.levelValueAlert]}>
          {nivelTanque !== null ? `${nivelTanque.toLocaleString()} L` : 'Sin datos'}
        </Text>
        {nivelBajo && <Text style={styles.alertText}>⚠ Nivel bajo mínimo de {LOW_LEVEL_THRESHOLD.toLocaleString()} L</Text>}
      </View>

      <Text style={styles.label}>Lectura manual de tanque</Text>
      <View style={styles.manualRow}>
        <TextInput
          style={styles.input}
          placeholder="Litros"
          placeholderTextColor={colors.textMuted}
          keyboardType="numeric"
          value={lecturaManual}
          onChangeText={setLecturaManual}
        />
        <TouchableOpacity style={styles.saveBtn} onPress={guardarLectura}>
          <Text style={styles.saveBtnText}>Guardar</Text>
        </TouchableOpacity>
      </View>

      <Text style={[styles.label, { marginTop: 24 }]}>Consumo por periodo</Text>
      <View style={styles.periodRow}>
        {PERIODS.map((p) => (
          <TouchableOpacity
            key={p.key}
            style={[styles.periodBtn, period === p.key && styles.periodBtnActive]}
            onPress={() => setPeriod(p.key)}
          >
            <Text style={[styles.periodText, period === p.key && styles.periodTextActive]}>{p.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.consumoRow}>
        <View style={styles.consumoCard}>
          <Text style={styles.consumoLabel}>Diésel</Text>
          <Text style={styles.consumoValue}>{consumo.diesel.toLocaleString()} L</Text>
        </View>
        <View style={styles.consumoCard}>
          <Text style={styles.consumoLabel}>Urea</Text>
          <Text style={styles.consumoValue}>{consumo.urea.toLocaleString()} L</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 16 },
  header: { color: colors.text, fontSize: 20, fontWeight: '800', marginBottom: 16 },
  levelCard: {
    backgroundColor: colors.surface, borderRadius: 14, padding: 18, borderWidth: 1, borderColor: colors.border, marginBottom: 20,
  },
  levelCardAlert: { borderColor: colors.danger, backgroundColor: '#2A1010' },
  levelLabel: { color: colors.textMuted, fontSize: 13 },
  levelValue: { color: colors.text, fontSize: 28, fontWeight: '800', marginTop: 4 },
  levelValueAlert: { color: colors.danger },
  alertText: { color: colors.danger, marginTop: 8, fontWeight: '700' },
  label: { color: colors.text, fontWeight: '700', marginBottom: 8 },
  manualRow: { flexDirection: 'row' },
  input: {
    flex: 1, backgroundColor: colors.surface, borderRadius: 10, borderWidth: 1, borderColor: colors.border,
    color: colors.text, padding: 12, marginRight: 10,
  },
  saveBtn: { backgroundColor: colors.accentYellow, paddingHorizontal: 18, borderRadius: 10, justifyContent: 'center' },
  saveBtnText: { color: '#000', fontWeight: '800' },
  periodRow: { flexDirection: 'row', marginBottom: 16 },
  periodBtn: {
    flex: 1, paddingVertical: 10, marginRight: 8, borderRadius: 10, backgroundColor: colors.surface,
    borderWidth: 1, borderColor: colors.border, alignItems: 'center',
  },
  periodBtnActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  periodText: { color: colors.textMuted, fontWeight: '700' },
  periodTextActive: { color: colors.text },
  consumoRow: { flexDirection: 'row', justifyContent: 'space-between' },
  consumoCard: {
    flex: 1, backgroundColor: colors.surface, borderRadius: 14, padding: 16, marginRight: 10,
    borderWidth: 1, borderColor: colors.border, alignItems: 'center',
  },
  consumoLabel: { color: colors.textMuted, fontSize: 13 },
  consumoValue: { color: colors.text, fontSize: 20, fontWeight: '800', marginTop: 4 },
});
