export const colors = {
  background: '#0D0D0D',
  surface: '#1A1A1A',
  surfaceAlt: '#242424',
  primary: '#D32F2F',
  primaryDark: '#8E0000',
  accentGreen: '#2E7D32',
  accentYellow: '#F9A825',
  accentBlue: '#1565C0',
  accentPurple: '#6A1B9A',
  text: '#FFFFFF',
  textMuted: '#B5B5B5',
  border: '#333333',
  danger: '#E53935',
  success: '#43A047',
  warning: '#FB8C00',
};

export default colors;
